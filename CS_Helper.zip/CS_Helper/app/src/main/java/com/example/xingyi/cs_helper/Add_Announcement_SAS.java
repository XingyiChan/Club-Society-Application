package com.example.xingyi.cs_helper;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Add_Announcement_SAS extends AppCompatActivity {

    private EditText editTitle;
    private EditText editDescription;
    private CheckBox checkStatus;
    private Button buttonSubmit;
    private Button buttonCancel;
    private Button addImage;
    private ImageView imageView;

    DatabaseHelper databaseHelper;
    View view;

    private final int REQUEST_CODE_GALLERY = 999;
    byte[] image;

    private Boolean clicked = false;

    private final String Channel_ID = "ann_notification";
    private final int Notification_ID = 001;
    private String title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_announcement);
        databaseHelper = new DatabaseHelper(this);

        initViews();

        addImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityCompat.requestPermissions(
                        Add_Announcement_SAS.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        REQUEST_CODE_GALLERY
                );
                clicked = true;
            }
        });

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Calendar calendar = Calendar.getInstance();
                SimpleDateFormat dateformat = new SimpleDateFormat("dd/MM/yyyy");

                title = editTitle.getText().toString();
                String desc = editDescription.getText().toString();
                String date = dateformat.format(calendar.getTime());
                if(imageView != null){
                    image = imageViewToByte(imageView);
                } else{
                    image = null;
                }
                String status;

                if(checkStatus.isChecked()){
                    status = "public";
                } else{
                    status = "private";
                }

                if(title.matches("")){
                    Toast.makeText(Add_Announcement_SAS.this, "Please enter title.", Toast.LENGTH_SHORT).show();
                } else {
                    databaseHelper.addAnnouncement(new Announcement_Model(null, title, desc, date, "Sunway Analytics Society", status, image));
                    Toast.makeText(Add_Announcement_SAS.this, "Announcement has been posted successfully!", Toast.LENGTH_SHORT).show();
                    setResult(10001);
                    displayNotification(view);
                    finish();
                }
            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTitle.getText().clear();
                editDescription.getText().clear();
                finish();
            }
        });
    }

    private void initViews(){
        editTitle = (EditText)findViewById(R.id.editText_Title);
        editDescription = (EditText)findViewById(R.id.editText_Description);
        checkStatus = (CheckBox) findViewById(R.id.checkBox_Status);
        buttonSubmit = (Button)findViewById(R.id.announcement_add);
        buttonCancel = (Button)findViewById(R.id.announcement_cancel);
        addImage = (Button)findViewById(R.id.addImage);
        imageView = (ImageView)findViewById(R.id.imageView);
    }

    public byte[] imageViewToByte(ImageView image) {
        if(clicked != false) {
            Bitmap bitmap = ((BitmapDrawable) image.getDrawable()).getBitmap();
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byte[] byteArray = stream.toByteArray();
            return byteArray;
        }
        return null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if(requestCode == REQUEST_CODE_GALLERY){
            if(grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, REQUEST_CODE_GALLERY);
            }
            else {
                Toast.makeText(getApplicationContext(), "You don't have permission to access file location!", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if(requestCode == REQUEST_CODE_GALLERY && resultCode == RESULT_OK && data != null){
            Uri uri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);

                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                imageView.setImageBitmap(bitmap);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void displayNotification(View view) {

        createNotificationChannel();

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, Channel_ID);
        builder.setSmallIcon(R.drawable.ic_notification);
        builder.setContentTitle("New Announcement from Sunway Analytics Society!");
        builder.setContentText(title);
        builder.setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(this);
        notificationManagerCompat.notify(Notification_ID, builder.build());
    }

    private void createNotificationChannel() {

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            CharSequence name = "Ann Notification";
            String description = "Include all the ann notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel notificationChannel = new NotificationChannel(Channel_ID, name, importance);
            notificationChannel.setDescription(description);

            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }
}
