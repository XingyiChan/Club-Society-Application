package com.example.xingyi.cs_helper;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Admin_Cheerleading_Members_Pending extends Fragment {

    private View view;
    private ArrayList<ClubUser> clubUsers;
    private DatabaseHelper databaseHelper;

    String club = "Sunway University Cheerleading";


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.admin_choir_members_pending, container, false);

        databaseHelper = new DatabaseHelper(getActivity());
        clubUsers = databaseHelper.getPendingClubMembers(club);
        final ClubUserAdapter clubUserAdapter;
        clubUserAdapter = new ClubUserAdapter(getActivity(), clubUsers);

        TextView memberPending = view.findViewById(R.id.textView_choir_members_pending);
        memberPending.setText(Html.fromHtml(clubUsers.size() + " member(s) pending."));

        ListView lv = (ListView) view.findViewById(android.R.id.list);
        lv.setAdapter(clubUserAdapter);
        lv.setSelected(true);

        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(final AdapterView<?> adapterView, View view, final int position, long l) {

                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage("Do you want to accept or reject this member?");

                builder.setPositiveButton("Accept", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String id = clubUsers.get(position).getCid();
                        String user = clubUsers.get(position).getCuser();
                        databaseHelper.acceptClubMember(id);
                        Toast.makeText(getActivity(), "Club member " + user + " has been accepted.", Toast.LENGTH_SHORT).show();
                        getFragmentManager().beginTransaction().detach(Admin_Cheerleading_Members_Pending.this).attach(Admin_Cheerleading_Members_Pending.this).commit();
                    }
                });

                builder.setNegativeButton("Reject", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String id = clubUsers.get(position).getCid();
                        String user = clubUsers.get(position).getCuser();
                        databaseHelper.deleteClubMember(id);
                        Toast.makeText(getActivity(), "Club member " + user + " has been rejected.", Toast.LENGTH_SHORT).show();
                        getFragmentManager().beginTransaction().detach(Admin_Cheerleading_Members_Pending.this).attach(Admin_Cheerleading_Members_Pending.this).commit();
                    }
                });

                builder.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });

                builder.show();
                return false;
            }
        });

        return view;
    }
}
