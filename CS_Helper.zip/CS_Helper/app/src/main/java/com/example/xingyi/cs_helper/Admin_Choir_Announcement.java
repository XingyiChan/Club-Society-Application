package com.example.xingyi.cs_helper;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Admin_Choir_Announcement extends Fragment {

    private View view;
    private ArrayList<Announcement_Model> announcement_model;
    private DatabaseHelper databaseHelper;
    private AnnouncementAdapter adapter;
    private String club = "Sunway University Choir";

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == 10001) && (resultCode == 10001)) {
            getFragmentManager().beginTransaction().detach(Admin_Choir_Announcement.this).attach(Admin_Choir_Announcement.this).commit();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.admin_choir_announcement, container, false);

        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.choir_add);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), Add_Announcement_Choir.class);
                startActivityForResult(intent, 10001);
                }
        });

        ListView lv = (ListView) view.findViewById(android.R.id.list);

        databaseHelper = new DatabaseHelper(getActivity());
        announcement_model = databaseHelper.getAllAnnouncement(club);
        adapter = new AnnouncementAdapter(getActivity(), announcement_model);
        lv.setAdapter(adapter);
        lv.setSelected(true);

        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(final AdapterView<?> adapterView, View view, final int position, long l) {

                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage("Are you sure to delete this announcement?");

                builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String id = announcement_model.get(position).getAnnouncementid();
                        databaseHelper.deleteAnnouncement(id);
                        Toast.makeText(getActivity(), "The announcement has been deleted.", Toast.LENGTH_SHORT).show();
                        getFragmentManager().beginTransaction().detach(Admin_Choir_Announcement.this).attach(Admin_Choir_Announcement.this).commit();
                    }
                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });

                builder.show();
                return false;
            }
        });

        return view;
    }
}