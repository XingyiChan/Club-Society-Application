package com.example.xingyi.cs_helper;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Admin_SSA_Members extends Fragment {

    private View view;
    private ArrayList<ClubUser> clubUsers;
    private ArrayList<ClubUser> pendingclubUsers;
    private DatabaseHelper databaseHelper;
    private ClubUserAdapter clubUserAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.admin_choir_members, container, false);

        String club = "Sunway Student Ambassadors";

        databaseHelper = new DatabaseHelper(getActivity());
        clubUsers = databaseHelper.getClubMembers(club);
        pendingclubUsers = databaseHelper.getPendingClubMembers(club);
        clubUserAdapter = new ClubUserAdapter(getActivity(), clubUsers);

        TextView memberTotal = view.findViewById(R.id.textView_choir_members);
        memberTotal.setText(Html.fromHtml(clubUsers.size() + " member(s) in total."));

        ImageButton fab = view.findViewById(R.id.choir_add_member);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Admin_SSA_Members_Pending nextFrag= new Admin_SSA_Members_Pending();
                getActivity().getSupportFragmentManager().beginTransaction().addToBackStack(null).replace(R.id.choir_container, nextFrag).commit();
            }
        });

        TextView dot = view.findViewById(R.id.choir_dot);
        if(pendingclubUsers.size() == 0){
            dot.setVisibility(view.INVISIBLE);
        }

        SwipeRefreshLayout refresh = view.findViewById(R.id.pullToRefresh_choir);
        refresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getFragmentManager().beginTransaction().detach(Admin_SSA_Members.this).attach(Admin_SSA_Members.this).commit();
            }
        });

        ListView lv = (ListView) view.findViewById(android.R.id.list);
        lv.setAdapter(clubUserAdapter);
        lv.setSelected(true);

        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(final AdapterView<?> adapterView, View view, final int position, long l) {

                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage("Delete this member / make member as admin?");

                builder.setPositiveButton("Remove", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String id = clubUsers.get(position).getCid();
                        String user = clubUsers.get(position).getCuser();
                        databaseHelper.deleteClubMember(id);
                        Toast.makeText(getActivity(), "Club member " + user + " has been removed.", Toast.LENGTH_SHORT).show();
                        getFragmentManager().beginTransaction().detach(Admin_SSA_Members.this).attach(Admin_SSA_Members.this).commit();
                    }
                });

                builder.setNegativeButton("Set Admin", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String id = clubUsers.get(position).getCid();
                        String user = clubUsers.get(position).getCuser();
                        databaseHelper.makeAdmin(id);
                        Toast.makeText(getActivity(), "Club member " + user + " is now an admin.", Toast.LENGTH_SHORT).show();
                        getFragmentManager().beginTransaction().detach(Admin_SSA_Members.this).attach(Admin_SSA_Members.this).commit();
                    }
                });

                builder.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });

                builder.show();
                return false;
            }
        });

        return view;
    }
}
