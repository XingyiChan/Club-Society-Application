package com.example.xingyi.cs_helper;

import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class Announcement extends ListFragment {

    View view;
    private ArrayList<Announcement_Model> announcement_model;
    private DatabaseHelper databaseHelper;
    private AnnouncementAdapter_Public adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_announcement, container, false);

        databaseHelper = new DatabaseHelper(getActivity());
        announcement_model = databaseHelper.getPublicAnnouncement();
        adapter = new AnnouncementAdapter_Public(getActivity(), announcement_model);
        setListAdapter(adapter);

        adapter.notifyDataSetChanged();

        ListView lv = (ListView) view.findViewById(android.R.id.list);

        return view;
    }
}

