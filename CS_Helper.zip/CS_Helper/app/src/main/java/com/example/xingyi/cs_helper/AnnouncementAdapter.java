package com.example.xingyi.cs_helper;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class AnnouncementAdapter extends BaseAdapter{

    private Activity activity;
    private LayoutInflater inflater;
    private ArrayList<Announcement_Model> annList;

    public AnnouncementAdapter(Activity activity, ArrayList<Announcement_Model> annList){
        this.activity = activity;
        this.annList = annList;
    }

    @Override
    public int getCount() {
        return annList.size();
    }

    @Override
    public Object getItem(int i) {
        return annList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        if(inflater == null){
            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if(view == null){
            view = inflater.inflate(R.layout.announcement_list, null);
        }

        TextView title = (TextView)view.findViewById(R.id.textViewTitle);
        TextView desc = (TextView)view.findViewById(R.id.textViewDescription);
        TextView date = (TextView)view.findViewById(R.id.textViewDate);
        ImageView image = (ImageView)view.findViewById(R.id.imageViewImage);

        Announcement_Model announcement_model = annList.get(i);
        if(announcement_model.getStatus().equalsIgnoreCase("public")){
            title.setText(Html.fromHtml(announcement_model.getTitle() + " (Public)"));
        } else if(announcement_model.getStatus().equalsIgnoreCase("private")){
            title.setText(announcement_model.getTitle());
        }
        desc.setText(Html.fromHtml(announcement_model.getDescription() + "\n"));
        date.setText(Html.fromHtml("posted on " + announcement_model.getDate()));

        byte[] recordImage = (announcement_model.getImage());
        if (recordImage == null){
            image.setImageDrawable(null);
        }
        else if (recordImage != null){
            Bitmap bitmap = BitmapFactory.decodeByteArray(recordImage, 0, recordImage.length);
            image.setImageBitmap(bitmap);
        }
        return view;
    }
}

