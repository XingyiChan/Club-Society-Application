package com.example.xingyi.cs_helper;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.content.ContextCompat;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class AnnouncementAdapter_Public extends BaseAdapter{

    private Activity activity;
    private LayoutInflater inflater;
    private ArrayList<Announcement_Model> annList;

    public AnnouncementAdapter_Public(Activity activity, ArrayList<Announcement_Model> annList){
        this.activity = activity;
        this.annList = annList;
    }


    @Override
    public int getCount() {
        return annList.size();
    }

    @Override
    public Object getItem(int i) {
        return annList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        if(inflater == null){
            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if(view == null){
            view = inflater.inflate(R.layout.announcement_list_public, null);
        }

        TextView title = (TextView)view.findViewById(R.id.ptextViewTitle);
        TextView club = (TextView)view.findViewById(R.id.ptextViewClub);
        TextView desc = (TextView)view.findViewById(R.id.ptextViewDescription);
        ImageView image = (ImageView)view.findViewById(R.id.pimageViewImage);

        Announcement_Model announcement_model = annList.get(i);
        title.setText(announcement_model.getTitle());
        club.setText(Html.fromHtml("posted by " + announcement_model.getClub() + " | " + announcement_model.getDate()));
        desc.setText(Html.fromHtml(announcement_model.getDescription() + "\n"));

        byte[] recordImage = (announcement_model.getImage());
        if (recordImage == null){
            image.setImageDrawable(null);
        }
        else if (recordImage != null){
            Bitmap bitmap = BitmapFactory.decodeByteArray(recordImage, 0, recordImage.length);
            image.setImageBitmap(bitmap);
        }

        return view;
    }
}
