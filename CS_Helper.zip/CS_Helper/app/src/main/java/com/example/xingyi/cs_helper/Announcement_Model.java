package com.example.xingyi.cs_helper;

public class Announcement_Model {

    private String announcementid;
    private String title;
    private String description;
    private String date;
    private String club;
    private String status;
    private byte[] image;

    public Announcement_Model(String announcementid, String title, String description, String date, String club, String status, byte[] image) {
        this.announcementid = announcementid;
        this.title = title;
        this.description = description;
        this.date = date;
        this.club = club;
        this.status = status;
        this.image = image;
    }

    public Announcement_Model(){
    }


    public String getAnnouncementid() {
        return announcementid;
    }

    public void setAnnouncementid(String announcementid) {
        this.announcementid = announcementid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getClub() {
        return club;
    }

    public void setClub(String club) {
        this.club = club;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }
}
