package com.example.xingyi.cs_helper;

public class ClubUser {

    public String cid;
    public String cuser;
    public String cemail;
    public String ccourse;
    public String cclub;
    public String cstatus;
    public String crole;

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getCuser() {
        return cuser;
    }

    public void setCuser(String cuser) {
        this.cuser = cuser;
    }

    public String getCemail() {
        return cemail;
    }

    public void setCemail(String cemail) {
        this.cemail = cemail;
    }

    public String getCcourse() {
        return ccourse;
    }

    public void setCcourse(String ccourse) {
        this.ccourse = ccourse;
    }

    public String getCclub() {
        return cclub;
    }

    public void setCclub(String cclub) {
        this.cclub = cclub;
    }

    public String getCstatus() {
        return cstatus;
    }

    public void setCstatus(String cstatus) {
        this.cstatus = cstatus;
    }

    public String getCrole() {
        return crole;
    }

    public void setCrole(String crole) {
        this.crole = crole;
    }

    public ClubUser(String cid, String cuser, String cemail, String ccourse, String cclub, String cstatus, String crole) {
        this.cid = cid;
        this.cuser = cuser;
        this.cemail = cemail;
        this.ccourse = ccourse;
        this.cclub = cclub;
        this.cstatus = cstatus;
        this.crole = crole;
    }

    public ClubUser() {

    }
}
