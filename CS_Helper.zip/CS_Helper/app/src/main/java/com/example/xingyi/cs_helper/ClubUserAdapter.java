package com.example.xingyi.cs_helper;

import android.app.Activity;
import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class ClubUserAdapter extends BaseAdapter{

    private Activity activity;
    private LayoutInflater inflater;
    private ArrayList<ClubUser> clubUserArrayList;

    public ClubUserAdapter(Activity activity, ArrayList<ClubUser> clubUserArrayList) {
        this.activity = activity;
        this.clubUserArrayList = clubUserArrayList;
    }

    @Override
    public int getCount() {
        return clubUserArrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return clubUserArrayList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        if(inflater == null){
            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if(view == null){
            view = inflater.inflate(R.layout.clubmember_list, null);
        }

        TextView name = (TextView)view.findViewById(R.id.textViewName);
        TextView email = (TextView)view.findViewById(R.id.textViewEmail);
        TextView course = (TextView)view.findViewById(R.id.textViewCourse);
        ImageView icon = (ImageView)view.findViewById(R.id.imageview_icon);
        TextView send = (TextView)view.findViewById(R.id.imageview_email);

        ClubUser clubUser = clubUserArrayList.get(i);
        String role = clubUser.getCrole();
        if(role.equalsIgnoreCase("admin")){
            name.setText(Html.fromHtml(clubUser.getCuser() + "<font color='red'> [Admin] </font>"));
        }else{
            name.setText(clubUser.getCuser());
        }
        email.setText(clubUser.getCemail());
        course.setText(clubUser.getCcourse());
        send.setText(clubUser.getCemail());

        Character ft = clubUser.getCuser().toUpperCase().charAt(0);

        ColorGenerator generator = ColorGenerator.MATERIAL;
        int color = generator.getRandomColor();

        TextDrawable drawable = TextDrawable.builder()
                .beginConfig()
                    .bold()
                .endConfig()
                .buildRound(ft.toString(), color);
        icon.setImageDrawable(drawable);

        return view;
    }
}
