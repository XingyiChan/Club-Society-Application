package com.example.xingyi.cs_helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    SQLiteDatabase db;

    public static final String Database_Name = "CSHelper.db";
    public static final int Database_Version = 1;

    public static final String Table_Users = "users";
    public static final String KEY_ID = "id";
    public static final String KEY_USER_NAME = "username";
    public static final String KEY_EMAIL = "email";
    public static final String KEY_PASSWORD = "password";

    public static final String Table_Announcements = "announcements";
    public static final String KEY_AID = "aid";
    public static final String KEY_TITLE = "title";
    public static final String KEY_DESCRIPTION = "description";
    public static final String KEY_DATE = "date";
    public static final String KEY_CLUB = "club";
    public static final String KEY_STATUS = "status";  //public or private
    public static final String KEY_IMAGE = "image";

    public static final String Table_ClubUser = "clubuser";
    public static final String KEY_CID = "cid";
    public static final String KEY_CUSER = "cuser";
    public static final String KEY_CEMAIL = "cemail";
    public static final String KEY_CCOURSE = "ccourse";
    public static final String KEY_CCLUB = "cclub";
    public static final String KEY_CSTATUS = "cstatus"; //accept or pending
    public static final String KEY_CROLE = "crole"; //admin or normal

    public static final String Table_Notice = "notice";
    public static final String KEY_NID = "nid";
    public static final String KEY_NEMAIL = "nemail";
    public static final String KEY_MSG = "msg";
    public static final String KEY_NDATE = "ndate";  //action date


    public static final String SQL_TABLE_USERS = " CREATE TABLE " + Table_Users
            + " ( "
            + KEY_ID + " INTEGER PRIMARY KEY, "
            + KEY_USER_NAME + " TEXT, "
            + KEY_EMAIL + " TEXT, "
            + KEY_PASSWORD + " TEXT "
            + " ) ";

    public static final String SQL_TABLE_ANNOUNCEMENTS = " CREATE TABLE " + Table_Announcements
            + " ( "
            + KEY_AID + " INTEGER PRIMARY KEY, "
            + KEY_TITLE + " TEXT, "
            + KEY_DESCRIPTION + " TEXT, "
            + KEY_DATE + " TEXT, "
            + KEY_CLUB + " TEXT, "
            + KEY_STATUS + " TEXT, "
            + KEY_IMAGE + " BLOB "
            + " ) ";

    public static final String SQL_TABLE_CLUBUSER = " CREATE TABLE " + Table_ClubUser
            + " ( "
            + KEY_CID + " INTEGER PRIMARY KEY, "
            + KEY_CUSER + " TEXT, "
            + KEY_CEMAIL + " TEXT, "
            + KEY_CCOURSE + " TEXT, "
            + KEY_CCLUB + " TEXT, "
            + KEY_CSTATUS + " TEXT, "
            + KEY_CROLE + " TEXT "
            + " ) ";

    public static final String SQL_TABLE_NOTICE = " CREATE TABLE " + Table_Notice
            + " ( "
            + KEY_NID + " INTEGER PRIMARY KEY, "
            + KEY_NEMAIL + " TEXT, "
            + KEY_MSG + " TEXT, "
            + KEY_NDATE + "TEXT "
            + " ) ";

    public DatabaseHelper(Context context) {
        super(context, Database_Name, null, Database_Version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(SQL_TABLE_USERS);
        sqLiteDatabase.execSQL(SQL_TABLE_ANNOUNCEMENTS);
        sqLiteDatabase.execSQL(SQL_TABLE_CLUBUSER);
        sqLiteDatabase.execSQL(SQL_TABLE_NOTICE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + Table_Users);
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + Table_Announcements);
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + Table_ClubUser);
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + Table_Notice);
    }

    public void addUser(User user) {

        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_USER_NAME, user.userName);
        values.put(KEY_EMAIL, user.email);
        values.put(KEY_PASSWORD, user.password);

        db.insert(Table_Users, null, values);
        db.close();
    }

    public User Authenticate(User user) {
        db = this.getReadableDatabase();
        Cursor cursor = db.query(Table_Users, new String[]{KEY_ID, KEY_USER_NAME, KEY_EMAIL, KEY_PASSWORD},//Selecting columns want to query
                KEY_EMAIL + "=?", new String[]{user.email},//Where clause
                null, null, null);

        if (cursor != null && cursor.moveToFirst()&& cursor.getCount()>0) {
            //if cursor has value then in user database there is user associated with this given email
            User user1 = new User(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3));

            //Match both passwords check they are same or not
            if (user.password.equalsIgnoreCase(user1.password)) {
                return user1;
            }
        }cursor.close();
        //if user password does not matches or there is no record with that email then return @false
        return null;
    }

    public boolean isEmailExists(String email) {
        db = this.getReadableDatabase();
        Cursor cursor = db.query(Table_Users,// Selecting Table
                new String[]{KEY_ID, KEY_USER_NAME, KEY_EMAIL, KEY_PASSWORD},//Selecting columns want to query
                KEY_EMAIL + "=?",
                new String[]{email},//Where clause
                null, null, null);

        if (cursor != null && cursor.moveToFirst()&& cursor.getCount()>0) {
            //if cursor has value then in user database there is user associated with this given email so return true
            return true;
        }cursor.close();
        //if email does not exist return false
        return false;
    }

    public boolean isEmailRegistered(String email, String club) {
        db = this.getReadableDatabase();
        //Cursor cursor = db.query(Table_ClubUser,// Selecting Table
                //new String[]{KEY_CID,KEY_CUSER, KEY_CEMAIL, KEY_CCOURSE, KEY_CCLUB},//Selecting columns want to query
                //KEY_CEMAIL + "=?", new String[]{email},//Where clause
                //null, null, null);

        Cursor cursor = db.rawQuery("Select * from ClubUser where cemail = \'" + email + "\' and cclub = '" + club + "'", null);
        if (cursor != null && cursor.moveToFirst()&& cursor.getCount()>0) {
            //if cursor has value then in user database there is user associated with this given email so return true
            return true;
        }
        //if email does not exist return false
        return false;
    }

    public void addClubUser(ClubUser clubUser){
        db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(KEY_CUSER, clubUser.getCuser());
        values.put(KEY_CEMAIL, clubUser.getCemail());
        values.put(KEY_CCOURSE, clubUser.getCcourse());
        values.put(KEY_CCLUB, clubUser.getCclub());
        values.put(KEY_CSTATUS, clubUser.getCstatus());
        values.put(KEY_CROLE, clubUser.getCrole());

        db.insert(Table_ClubUser, null, values);
        db.close();
    }

    private static final String[] CMallColumns = {
            KEY_CID, KEY_CUSER, KEY_CEMAIL, KEY_CCOURSE, KEY_CCLUB, KEY_CSTATUS, KEY_CROLE
    };

    //members that are accepted
    public ArrayList<ClubUser> getClubMembers(String club) {

        ArrayList<ClubUser> clubusers = new ArrayList<ClubUser>();

        String query = "Select * from clubuser where cstatus = 'accept' and cclub = '";

        db = getReadableDatabase();

        Cursor cursor = db.rawQuery(query + club + "'" + "order by cuser asc", null);
        if(cursor.getCount() > 0){
            while(cursor.moveToNext()){
                ClubUser clubUser = new ClubUser();
                clubUser.setCid(cursor.getString(cursor.getColumnIndex(KEY_CID)));
                clubUser.setCuser(cursor.getString(cursor.getColumnIndex(KEY_CUSER)));
                clubUser.setCemail(cursor.getString(cursor.getColumnIndex(KEY_CEMAIL)));
                clubUser.setCcourse(cursor.getString(cursor.getColumnIndex(KEY_CCOURSE)));
                clubUser.setCclub(cursor.getString(cursor.getColumnIndex(KEY_CCLUB)));
                clubUser.setCstatus(cursor.getString(cursor.getColumnIndex(KEY_CSTATUS)));
                clubUser.setCrole(cursor.getString(cursor.getColumnIndex(KEY_CROLE)));
                clubusers.add(clubUser);
            }cursor.close();
        }
        return clubusers;
        }

    //members that are still pending
    public ArrayList<ClubUser> getPendingClubMembers(String club) {

        ArrayList<ClubUser> clubusers = new ArrayList<ClubUser>();

        String query = "Select * from clubuser where cstatus = 'pending' and cclub = '";


        db = getReadableDatabase();
        Cursor cursor = db.rawQuery(query + club + "'", null);

        if(cursor.getCount() > 0){
            while(cursor.moveToNext()){
                ClubUser clubUser = new ClubUser();
                clubUser.setCid(cursor.getString(cursor.getColumnIndex(KEY_CID)));
                clubUser.setCuser(cursor.getString(cursor.getColumnIndex(KEY_CUSER)));
                clubUser.setCemail(cursor.getString(cursor.getColumnIndex(KEY_CEMAIL)));
                clubUser.setCcourse(cursor.getString(cursor.getColumnIndex(KEY_CCOURSE)));
                clubUser.setCclub(cursor.getString(cursor.getColumnIndex(KEY_CCLUB)));
                clubUser.setCstatus(cursor.getString(cursor.getColumnIndex(KEY_CSTATUS)));
                clubUser.setCrole(cursor.getString(cursor.getColumnIndex(KEY_CROLE)));
                clubusers.add(clubUser);
            }cursor.close();
        }
        return clubusers;
    }

    public void deleteClubMember(String id){
        db = this.getWritableDatabase();

        db.delete(Table_ClubUser, KEY_CID + " = ?", new String[]{id});
        db.close();
    }

    public void acceptClubMember(String id){
        db = this.getWritableDatabase();

        db.execSQL("update ClubUser set CSTATUS = 'accept' where CID = " + id);
        db.close();
    }

    public void makeAdmin(String id){
        db = this.getWritableDatabase();

        db.execSQL("update ClubUser set CROLE = 'admin' where CID = " + id);
        db.close();
    }

    public void makeSysAdmin(String user){
        db = this.getWritableDatabase();

        db.execSQL("update ClubUser set CROLE = 'sysadmin' where CUSER = " + user);
        db.close();
    }

    public void addAnnouncement(Announcement_Model announcement){
        db = this.getWritableDatabase();

        ContentValues values  = new ContentValues();
        values.put(KEY_TITLE, announcement.getTitle());
        values.put(KEY_DESCRIPTION, announcement.getDescription());
        values.put(KEY_DATE, announcement.getDate());
        values.put(KEY_CLUB, announcement.getClub());
        values.put(KEY_STATUS, announcement.getStatus());
        values.put(KEY_IMAGE, announcement.getImage());

        db.insert(Table_Announcements, null, values);
        db.close();
    }

    public void deleteAnnouncement(String id) {
        db = this.getWritableDatabase();

        db.delete(Table_Announcements, KEY_AID + " =? ", new String[]{id});
        db.close();
    }

    private static final String[] allColumns = {
            KEY_AID, KEY_TITLE, KEY_DESCRIPTION, KEY_DATE, KEY_CLUB, KEY_STATUS, KEY_IMAGE
    };

    //announcement within the club according to respective club name
    public ArrayList<Announcement_Model> getAllAnnouncement(String club) {

        ArrayList<Announcement_Model> announcements = new ArrayList<Announcement_Model>();

        db = getReadableDatabase();
        Cursor cursor = db.query(Table_Announcements,allColumns,"CLUB" + "=?",new String[] {club},null, null, "AID DESC");

        if(cursor.getCount() > 0){
            while(cursor.moveToNext()){
                Announcement_Model announcement = new Announcement_Model();
                announcement.setAnnouncementid(cursor.getString(cursor.getColumnIndex(KEY_AID)));
                announcement.setTitle(cursor.getString(cursor.getColumnIndex(KEY_TITLE)));
                announcement.setDescription(cursor.getString(cursor.getColumnIndex(KEY_DESCRIPTION)));
                announcement.setDate(cursor.getString(cursor.getColumnIndex(KEY_DATE)));
                announcement.setClub(cursor.getString(cursor.getColumnIndex(KEY_CLUB)));
                announcement.setStatus(cursor.getString(cursor.getColumnIndex(KEY_STATUS)));
                announcement.setImage(cursor.getBlob(cursor.getColumnIndex(KEY_IMAGE)));
                announcements.add(announcement);
            }cursor.close();
        }
        return announcements;
    }

    //public announcement
    public ArrayList<Announcement_Model> getPublicAnnouncement() {

        ArrayList<Announcement_Model> announcements = new ArrayList<Announcement_Model>();

        db = getReadableDatabase();
        String[] where = {"public"};
        Cursor cursor = db.query(Table_Announcements, allColumns, "STATUS" + "=?", where, null, null, "AID DESC");

        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                Announcement_Model announcement = new Announcement_Model();
                announcement.setAnnouncementid(cursor.getString(cursor.getColumnIndex(KEY_AID)));
                announcement.setTitle(cursor.getString(cursor.getColumnIndex(KEY_TITLE)));
                announcement.setDescription(cursor.getString(cursor.getColumnIndex(KEY_DESCRIPTION)));
                announcement.setDate(cursor.getString(cursor.getColumnIndex(KEY_DATE)));
                announcement.setClub(cursor.getString(cursor.getColumnIndex(KEY_CLUB)));
                announcement.setStatus(cursor.getString(cursor.getColumnIndex(KEY_STATUS)));
                announcement.setImage(cursor.getBlob(cursor.getColumnIndex(KEY_IMAGE)));
                announcements.add(announcement);
            }cursor.close();
        }
        return announcements;
    }

    //get user's username using user's email
    public User getUsername(String email){
        db = this.getReadableDatabase();

        String query = "select username from users where email = \'" + email+"\'";
        Cursor cursor = db.rawQuery(query, null);
        User users = new User();

        if(cursor != null){
            cursor.moveToFirst();
        }
        users.setUserName(cursor.getString(cursor.getColumnIndex(KEY_USER_NAME)));
        cursor.close();
        return users;
    }

    //get list for MyCS
    public ArrayList<ClubUser> getMyCS(String email){
        ArrayList<ClubUser> clubUsers = new ArrayList<>();

        db = getReadableDatabase();
        String query = "select * from clubuser where cemail = \'" + email+"\' and cstatus = 'accept'";
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                ClubUser clubUser = new ClubUser();
                clubUser.setCid(cursor.getString(cursor.getColumnIndex(KEY_CID)));
                clubUser.setCuser(cursor.getString(cursor.getColumnIndex(KEY_CUSER)));
                clubUser.setCemail(cursor.getString(cursor.getColumnIndex(KEY_CEMAIL)));
                clubUser.setCcourse(cursor.getString(cursor.getColumnIndex(KEY_CCOURSE)));
                clubUser.setCclub(cursor.getString(cursor.getColumnIndex(KEY_CCLUB)));
                clubUser.setCstatus(cursor.getString(cursor.getColumnIndex(KEY_CSTATUS)));
                clubUser.setCrole(cursor.getString(cursor.getColumnIndex(KEY_CROLE)));
                clubUsers.add(clubUser);
            }cursor.close();
        }
        return clubUsers;
    }

    /*public void addNotice(Notice_Model notice) {
        db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NEMAIL, notice.getNemail());
        values.put(KEY_MSG, notice.getMsg());
        values.put(KEY_NDATE, notice.getNdate());

        db.insert(Table_Notice, null, values);
        db.close();
    }*/

    // get notice for respective users
    public ArrayList<Notice_Model> getNotice(String email){
        ArrayList<Notice_Model> notices = new ArrayList<Notice_Model>();

        db = getReadableDatabase();
        String query = "select * from notice where nemail = \'" + email+"\'";
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.getCount() > 0){
            while(cursor.moveToNext()){
                Notice_Model notice = new Notice_Model();
                notice.setNid(cursor.getString(cursor.getColumnIndex(KEY_NID)));
                notice.setNemail(cursor.getString(cursor.getColumnIndex(KEY_NEMAIL)));
                notice.setMsg(cursor.getString(cursor.getColumnIndex(KEY_MSG)));
                notice.setNdate(cursor.getString(cursor.getColumnIndex(KEY_NDATE)));
                notices.add(notice);
            }cursor.close();
        }
        return notices;
    }

} // end of class


