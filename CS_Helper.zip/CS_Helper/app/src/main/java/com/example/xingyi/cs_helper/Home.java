package com.example.xingyi.cs_helper;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Home extends Fragment {

    private ExpandableListView listView;
    private ClubAdapter listAdapter;
    private List<String> listDataHeader;
    private HashMap<String,List<String>> listHash;
    private int lastPosition = -1;
    View view;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_home, container, false);

        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState){

        super.onActivityCreated(savedInstanceState);
        listView = (ExpandableListView)view.findViewById(R.id.ListView);

        setData();
        listAdapter = new ClubAdapter(getActivity(),listDataHeader,listHash);
        listView.setAdapter(listAdapter);

        //expand one group at a time
        listView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

            @Override
            public void onGroupExpand(int groupPosition) {
                if (lastPosition != -1
                        && groupPosition != lastPosition) {
                    listView.collapseGroup(lastPosition);
                }
                lastPosition = groupPosition;
            }
        });

        listView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView expandableListView, View view, int i, int i1, long l) {

                String selected = (String) listAdapter.getChild(i, i1);

                Fragment myFragment = null;
                Class fragmentClass = null;
                String clubTitle = null;
                switch (selected){
                    case "Sunway University Choir":
                        fragmentClass = Sunway_University_Choir.class;
                        clubTitle = "Sunway University Choir";
                        break;
                    case "Sunway Music Society":
                        fragmentClass = Sunway_Student_Volunteer.class;
                        clubTitle = "Sunway Student Volunteers (SSV)";
                        break;
                    case "Sunway Photography Club":
                        fragmentClass = Sunway_Student_Volunteer.class;
                        clubTitle = "Sunway Student Volunteers (SSV)";
                        break;
                    case "Sunway Analytics Society (SAS)":
                        fragmentClass = Sunway_Analytics_Society.class;
                        clubTitle = "Sunway Analytics Society (SAS)";
                        break;
                    case "Sunway Tech Club":
                        fragmentClass = Sunway_Tech_Club.class;
                        clubTitle = "Sunway Tech Club";
                        break;
                    case "Sunway Badminton Club":
                        fragmentClass = Sunway_Student_Volunteer.class;
                        clubTitle = "Sunway Student Volunteers (SSV)";
                        break;
                    case "Sunway University Cheerleading":
                        fragmentClass = Sunway_University_Cheerleading.class;
                        clubTitle = "Sunway University Cheerleading";
                        break;
                    case "Sunway Student Ambassadors":
                        fragmentClass = Sunway_Student_Ambassadors.class;
                        clubTitle = "Sunway Student Ambassadors";
                        break;
                    case "Sunway Student Volunteers (SSV)":
                        fragmentClass = Sunway_Student_Volunteer.class;
                        clubTitle = "Sunway Student Volunteers (SSV)";
                        break;
                    case "Psychology Club":
                        fragmentClass = Sunway_Student_Volunteer.class;
                        clubTitle = "Sunway Student Volunteers (SSV)";
                        break;
                    case "Sunway E-Sports Club":
                        fragmentClass = Sunway_Student_Volunteer.class;
                        clubTitle = "Sunway Student Volunteers (SSV)";
                        break;
                    case "Sunway University Korean Club":
                        fragmentClass = Sunway_Student_Volunteer.class;
                        clubTitle = "Sunway Student Volunteers (SSV)";
                        break;
                    case "Sunway Japanese Club":
                        fragmentClass = Sunway_Student_Volunteer.class;
                        clubTitle = "Sunway Student Volunteers (SSV)";
                        break;
                    case "Kendo Club":
                        fragmentClass = Sunway_Student_Volunteer.class;
                        clubTitle = "Sunway Student Volunteers (SSV)";
                        break;
                    case "Muay Thai":
                        fragmentClass = Sunway_Student_Volunteer.class;
                        clubTitle = "Sunway Student Volunteers (SSV)";
                        break;
                    case "Taekwondo Club (WTF)":
                        fragmentClass = Sunway_Student_Volunteer.class;
                        clubTitle = "Sunway Student Volunteers (SSV)";
                        break;
                    case "Sunway Accounting & Commerce Society":
                        fragmentClass = Sunway_Student_Volunteer.class;
                        clubTitle = "Sunway Student Volunteers (SSV)";
                        break;
                    case "Sunway Actuarial & Financial Excellence Society":
                        fragmentClass = Sunway_Student_Volunteer.class;
                        clubTitle = "Sunway Student Volunteers (SSV)";
                        break;
                    case "Sunway University Chinese Cultural Society":
                        fragmentClass = Sunway_University_Chinese.class;
                        clubTitle = "Sunway University Chinese Cultural Society";
                        break;
                }
                try{
                    myFragment = (Fragment) fragmentClass.newInstance();
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.club,myFragment).addToBackStack(null).commit();
                getActivity().setTitle(clubTitle);
                expandableListView.collapseGroup(i); // collapse group once child item is clicked

                return true;
            }
        });
    }

    public void setData(){
        listDataHeader = new ArrayList<>();
        listHash = new HashMap<>();

        listDataHeader.add("Arts & Music");
        listDataHeader.add("General");
        listDataHeader.add("Sports Club");
        listDataHeader.add("Cultural");
        listDataHeader.add("Student Volunteer Groups");
        listDataHeader.add("Martial Arts Clubs");
        listDataHeader.add("Accounting & Finance");


        List<String> ArtsMusic = new ArrayList<>();
        ArtsMusic.add("Sunway University Choir");
        ArtsMusic.add("Sunway Music Society");

        List<String> General = new ArrayList<>();
        General.add("Sunway Photography Club");
        General.add("Sunway Analytics Society (SAS)");
        General.add("Sunway Tech Club");
        General.add("Psychology Club");
        General.add("Sunway E-Sports Club");

        List<String> SportsClub = new ArrayList<>();
        SportsClub.add("Sunway Badminton Club");
        SportsClub.add("Sunway University Cheerleading");

        List<String> Cultural = new ArrayList<>();
        Cultural.add("Sunway University Chinese Cultural Society");
        Cultural.add("Sunway University Korean Club");
        Cultural.add("Sunway Japanese Club");

        List<String> SVG = new ArrayList<>();
        SVG.add("Sunway Student Ambassadors");
        SVG.add("Sunway Student Volunteers (SSV)");

        List<String> MartialArts = new ArrayList<>();
        MartialArts.add("Kendo Club");
        MartialArts.add("Muay Thai");
        MartialArts.add("Taekwondo Club (WTF)");

        List<String> AF = new ArrayList<>();
        AF.add("Sunway Accounting & Commerce Society");
        AF.add("Sunway Actuarial & Financial Excellence Society");


        listHash.put(listDataHeader.get(0),ArtsMusic);
        listHash.put(listDataHeader.get(1),General);
        listHash.put(listDataHeader.get(2),SportsClub);
        listHash.put(listDataHeader.get(3),Cultural);
        listHash.put(listDataHeader.get(4),SVG);
        listHash.put(listDataHeader.get(5),MartialArts);
        listHash.put(listDataHeader.get(6),AF);
    }
}
