package com.example.xingyi.cs_helper;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    SessionManagement session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.Open,R.string.Close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        NavigationView nvDrawer = (NavigationView) findViewById(R.id.design_navigation_view);
        View header = nvDrawer.getHeaderView(0);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setupDrawerContent(nvDrawer);

        session = new SessionManagement(getApplicationContext());

        HashMap<String, String> user = session.getUserDetails();

        String name = user.get(SessionManagement.KEY_NAME);
        String email = user.get(SessionManagement.KEY_EMAIL);

        //ImageView image = (ImageView) header.findViewById(R.id.avatar);
        TextView txt1 = (TextView) header.findViewById(R.id.txtViewusername);
        TextView txt2 = (TextView) header.findViewById(R.id.txtViewemail);

        if(session.isLoggedIn() == false){
            nvDrawer.getMenu().findItem(R.id.signin).setVisible(true);
            nvDrawer.getMenu().findItem(R.id.logout).setVisible(false);
            txt1.setText(" ");
            txt2.setText(" ");

        } else {
            nvDrawer.getMenu().findItem(R.id.signin).setVisible(false);
            nvDrawer.getMenu().findItem(R.id.logout).setVisible(true);
            txt1.setText(Html.fromHtml("<b>" + name + "</b>"));
            txt2.setText(Html.fromHtml("<b>" + email + "</b>"));
        }
        /*image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(session.isLoggedIn() == false){
                    Toast.makeText(getApplicationContext(), "Please Sign In.", Toast.LENGTH_LONG).show();
                } else{
                    Intent intent = new Intent(getApplicationContext(), User_Profile.class);
                    //startActivity(intent);
                    startActivityForResult(intent, 1);
                }
            }
        });*/

        //default fragment
        loadFragment(new Home());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            Intent refresh = new Intent(this, MainActivity.class);
            startActivity(refresh);
            this.finish();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void selectItemDrawer(MenuItem menuItem){
        Fragment myFragment = null;
        Class fragmentClass;
        switch (menuItem.getItemId()){
            case R.id.home:
                fragmentClass = Home.class;
                break;
            case R.id.announcement:
                fragmentClass = Announcement.class;
                break;
            case R.id.mycs:
                fragmentClass = MyCS.class;
                break;
            case R.id.logout:
                Intent refresh = new Intent(this, MainActivity.class);
                startActivity(refresh);
                this.finish();
                session.logoutUser();
            default:
                fragmentClass = Home.class;
        }
        try{
            myFragment = (Fragment) fragmentClass.newInstance();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.content,myFragment).commit();

        setTitle(menuItem.getTitle());

        switch (menuItem.getItemId()) {
            case R.id.signin:
                if(session.isLoggedIn() == false) {
                    Intent intent = new Intent(this, SignIn.class);
                    //startActivity(intent);
                    startActivityForResult(intent, 1);
                }
                break;
        }
        menuItem.setChecked(true);
        mDrawerLayout.closeDrawers();
    }

    private void setupDrawerContent(NavigationView navigationView){
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                selectItemDrawer(item);
                return true;
            }
        });
    }

    private boolean loadFragment(Fragment fragment){
        if(fragment != null){
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.content, fragment)
                    .commit();
            return true;
        }
        return false;
    }
}
