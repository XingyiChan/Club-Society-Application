package com.example.xingyi.cs_helper;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

public class Member_Register_SSV extends AppCompatActivity {

    SessionManagement session;
    DatabaseHelper databaseHelper;
    private TextView ctitle;
    private TextView cname;
    private TextView cemail;
    private EditText ccourse;
    private Button btnregister;
    private Button btncancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.clubmember_registration);
        databaseHelper = new DatabaseHelper(this);

        session = new SessionManagement(getApplicationContext());

        ctitle = (TextView) findViewById(R.id.ctitle);
        cname = (TextView) findViewById(R.id.cname);
        cemail = (TextView) findViewById(R.id.cemail);
        ccourse = (EditText) findViewById(R.id.ccourse);
        btnregister = (Button) findViewById(R.id.btn_register);
        btncancel = (Button) findViewById(R.id.btn_cancel);

        HashMap<String, String> user = session.getUserDetails();
        final String sm_name = user.get(SessionManagement.KEY_NAME);
        final String sm_email = user.get(SessionManagement.KEY_EMAIL);

        ctitle.setText("Sunway Student Volunteers");
        cname.setText(Html.fromHtml("Name: <b>" + sm_name + "</b>"));
        cemail.setText(Html.fromHtml("Email: <b>" + sm_email + "</b>"));

        final String email = sm_email.toString();
        final String club = "Sunway Student Volunteers";

        if(databaseHelper.isEmailRegistered(email, club)){
            Toast.makeText(Member_Register_SSV.this, "You have already registered.", Toast.LENGTH_SHORT).show();
            finish();
        }

        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = sm_name.toString();
                String email = sm_email.toString();
                String course = ccourse.getText().toString();

                if(course.matches("")){
                    Toast.makeText(Member_Register_SSV.this, "Please enter your course.", Toast.LENGTH_SHORT).show();
                } else if(databaseHelper.isEmailRegistered(email, club)){
                    Toast.makeText(Member_Register_SSV.this, "You have already registered.", Toast.LENGTH_SHORT).show();
                } else{
                    databaseHelper.addClubUser(new ClubUser(null, name, email, course, club, "pending", "normal"));
                    Toast.makeText(Member_Register_SSV.this, "You have registered successfully!", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });

        btncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ccourse.getText().clear();
                finish();
            }
        });
    }
}
