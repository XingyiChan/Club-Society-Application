package com.example.xingyi.cs_helper;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class MyCS extends Fragment {

    ListView mycsList;
    String[] csList = {"Sunway University Choir", "Sunway Tech Club", "Sunway Analytics Society", "Sunway Student Ambassadors", "Sunway Student Volunteers", "Sunway University Cheerleading", "Sunway University Chinese Cultural Society"};
    private View view;
    private ArrayList<ClubUser> clubUsers;
    private DatabaseHelper databaseHelper;
    private MyCSAdapter adapter;

    SessionManagement session;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_mycs, container, false);

        ImageView imageView = (ImageView) view.findViewById(R.id.imageView_mycs);
        ListView lv = (ListView) view.findViewById(android.R.id.list);

        session = new SessionManagement(getActivity());
        HashMap<String, String> user = session.getUserDetails();
        final String name = user.get(SessionManagement.KEY_NAME);
        final String email = user.get(SessionManagement.KEY_EMAIL);

        databaseHelper = new DatabaseHelper(getActivity());
        clubUsers = databaseHelper.getMyCS(email);
        adapter = new MyCSAdapter(getActivity(), clubUsers);

        if(session.isLoggedIn() && clubUsers.size() == 0 && !name.equalsIgnoreCase("system")){
            imageView.setImageResource(R.drawable.no_club_available);
        }else if(session.isLoggedIn() && clubUsers.size() != 0){
            imageView.setImageDrawable(null);
        }else if(name.equalsIgnoreCase("system")){
            imageView.setImageDrawable(null);
        }else{
            imageView.setImageResource(R.drawable.please_sign_in);
        }

        lv.setAdapter(adapter);
        lv.setSelected(true);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String club = clubUsers.get(i).getCclub();
                String role = clubUsers.get(i).getCrole();

                if(role.equalsIgnoreCase("sysadmin")|| club.equalsIgnoreCase("Sunway University Choir") && role.equalsIgnoreCase("admin")){
                    Intent intent = new Intent(getActivity(), Admin_Choir.class);
                    startActivity(intent);
                } else if(club.equalsIgnoreCase("Sunway University Choir") && role.equalsIgnoreCase("normal")){
                    Intent intent = new Intent(getActivity(), Normal_Choir.class);
                    startActivity(intent);
                } else if(role.equalsIgnoreCase("sysadmin")|| club.equalsIgnoreCase("Sunway Tech Club") && role.equalsIgnoreCase("admin")){
                    Intent intent = new Intent(getActivity(), Admin_TechClub.class);
                    startActivity(intent);
                } else if(club.equalsIgnoreCase("Sunway Tech Club") && role.equalsIgnoreCase("normal")){
                    Intent intent = new Intent(getActivity(), Normal_TechClub.class);
                    startActivity(intent);
                } else if(role.equalsIgnoreCase("sysadmin")|| club.equalsIgnoreCase("Sunway Analytics Society") && role.equalsIgnoreCase("admin")){
                    Intent intent = new Intent(getActivity(), Admin_SAS.class);
                    startActivity(intent);
                } else if(club.equalsIgnoreCase("Sunway Analytics Society") && role.equalsIgnoreCase("normal")){
                    Intent intent = new Intent(getActivity(), Normal_SAS.class);
                    startActivity(intent);
                } else if(role.equalsIgnoreCase("sysadmin")|| club.equalsIgnoreCase("Sunway Student Ambassadors") && role.equalsIgnoreCase("admin")){
                    Intent intent = new Intent(getActivity(), Admin_SSA.class);
                    startActivity(intent);
                } else if(club.equalsIgnoreCase("Sunway Student Ambassadors") && role.equalsIgnoreCase("normal")){
                    Intent intent = new Intent(getActivity(), Normal_SSA.class);
                    startActivity(intent);
                } else if(role.equalsIgnoreCase("sysadmin")|| club.equalsIgnoreCase("Sunway Student Volunteers") && role.equalsIgnoreCase("admin")){
                    Intent intent = new Intent(getActivity(), Admin_SSV.class);
                    startActivity(intent);
                } else if(club.equalsIgnoreCase("Sunway Student Volunteers") && role.equalsIgnoreCase("normal")){
                    Intent intent = new Intent(getActivity(), Normal_SSV.class);
                    startActivity(intent);
                } else if(role.equalsIgnoreCase("sysadmin")|| club.equalsIgnoreCase("Sunway University Cheerleading") && role.equalsIgnoreCase("admin")){
                    Intent intent = new Intent(getActivity(), Admin_Cheerleading.class);
                    startActivity(intent);
                } else if(club.equalsIgnoreCase("Sunway University Cheerleading") && role.equalsIgnoreCase("normal")){
                    Intent intent = new Intent(getActivity(), Normal_Cheerleading.class);
                    startActivity(intent);
                } else if(role.equalsIgnoreCase("sysadmin")|| club.equalsIgnoreCase("Sunway University Chinese Cultural Society") && role.equalsIgnoreCase("admin")){
                    Intent intent = new Intent(getActivity(), Admin_Chinese.class);
                    startActivity(intent);
                } else if(club.equalsIgnoreCase("Sunway University Chinese Cultural Society") && role.equalsIgnoreCase("normal")){
                    Intent intent = new Intent(getActivity(), Normal_Chinese.class);
                    startActivity(intent);
                }
            }
        });

        /*Intent intent = new Intent(getActivity(), Admin_TechClub.class);
        startActivity(intent);
*/
        if(name.equalsIgnoreCase("system")){
            mycsList = (ListView)view.findViewById(android.R.id.list);
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getActivity(), R.layout.mycs_listview, R.id.MyCSTextView, csList);
            mycsList.setAdapter(arrayAdapter);
            mycsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    if(i == 0){
                        Intent intent = new Intent(getActivity(), Admin_Choir.class);
                        startActivityForResult(intent, 0);
                    }
                    if(i == 1){
                        Intent intent = new Intent(getActivity(), Admin_TechClub.class);
                        startActivityForResult(intent, 1);
                    }
                    if(i == 2){
                        Intent intent = new Intent(getActivity(), Admin_SAS.class);
                        startActivityForResult(intent, 2);
                    }
                    if(i == 3){
                        Intent intent = new Intent(getActivity(), Admin_SSA.class);
                        startActivityForResult(intent, 3);
                    }
                    if(i == 4){
                        Intent intent = new Intent(getActivity(), Admin_SSV.class);
                        startActivityForResult(intent, 4);
                    }
                    if(i == 5){
                        Intent intent = new Intent(getActivity(), Admin_Cheerleading.class);
                        startActivityForResult(intent, 5);
                    }
                    if(i == 6){
                        Intent intent = new Intent(getActivity(), Admin_Chinese.class);
                        startActivityForResult(intent, 6);
                    }
                }
            });
        }

        return view;
    }
}
