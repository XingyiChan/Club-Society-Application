package com.example.xingyi.cs_helper;

import android.app.ListActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.ListView;

import java.util.ArrayList;

public class Normal_Chinese extends ListActivity {

    private ArrayList<Announcement_Model> announcement_model;
    private DatabaseHelper databaseHelper;
    private AnnouncementAdapter adapter;
    private String club = "Sunway University Chinese Cultural Society";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.normal_choir);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_choir);
        toolbar.setTitle("SUCCS Announcements");
        toolbar.setTitleTextColor(Color.WHITE);

        ListView lv = (ListView) findViewById(android.R.id.list);

        databaseHelper = new DatabaseHelper(this);
        announcement_model = databaseHelper.getAllAnnouncement(club);
        adapter = new AnnouncementAdapter(this, announcement_model);
        lv.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }
}
