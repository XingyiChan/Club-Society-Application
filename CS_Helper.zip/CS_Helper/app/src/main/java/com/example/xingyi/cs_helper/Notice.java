package com.example.xingyi.cs_helper;

import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class Notice extends ListFragment {

    View view;
    private ArrayList<Notice_Model> notice_model;
    private DatabaseHelper databaseHelper;
    private Notice_Adapter adapter;
    SessionManagement session;

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_notice, container, false);

        session = new SessionManagement(getActivity());
        HashMap<String, String> user = session.getUserDetails();
        String email = user.get(SessionManagement.KEY_EMAIL);

        databaseHelper = new DatabaseHelper(getActivity());
        notice_model = databaseHelper.getNotice(email);
        adapter = new Notice_Adapter(getActivity(), notice_model);
        setListAdapter(adapter);

        adapter.notifyDataSetChanged();

        ListView lv = (ListView) view.findViewById(android.R.id.list);

        if(session.isLoggedIn() == false){
            Toast.makeText(getActivity(), "Please Sign In.", Toast.LENGTH_LONG).show();
        } else if(notice_model.size() == 0){
            Toast.makeText(getActivity(), "You does not have any notices yet.", Toast.LENGTH_LONG).show();
        }

        return view;
    }
}
