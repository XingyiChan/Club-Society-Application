package com.example.xingyi.cs_helper;

import android.app.Activity;
import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class Notice_Adapter extends BaseAdapter {

    private Activity activity;
    private LayoutInflater inflater;
    private ArrayList<Notice_Model> noticeArrayList;

    public Notice_Adapter(Activity activity, ArrayList<Notice_Model> noticeArrayList) {
        this.activity = activity;
        this.noticeArrayList = noticeArrayList;
    }

    @Override
    public int getCount() {
        return noticeArrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return noticeArrayList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        if(inflater == null){
            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if(view == null){
            view = inflater.inflate(R.layout.notice_listview, null);
        }

        TextView msg = (TextView)view.findViewById(R.id.textViewMsg);
        TextView date = (TextView)view.findViewById(R.id.textViewNDate);

        Notice_Model notice = noticeArrayList.get(i);
        msg.setText(notice.getMsg());
        date.setText(notice.getNdate());

        return view;
    }
}
