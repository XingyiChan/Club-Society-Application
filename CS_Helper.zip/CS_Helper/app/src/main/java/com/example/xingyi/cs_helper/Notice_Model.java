package com.example.xingyi.cs_helper;

public class Notice_Model {

    private String nid;
    private String nemail;
    private String msg;
    private String ndate;

    public Notice_Model(String nid, String nemail, String msg, String ndate) {
        this.nid = nid;
        this.nemail = nemail;
        this.msg = msg;
        this.ndate = ndate;
    }

    public String getNid() {
        return nid;
    }

    public void setNid(String nid) {
        this.nid = nid;
    }

    public String getNemail() {
        return nemail;
    }

    public void setNemail(String nemail) {
        this.nemail = nemail;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getNdate() {
        return ndate;
    }

    public void setNdate(String ndate) {
        this.ndate = ndate;
    }

    public Notice_Model() {
    }
}
