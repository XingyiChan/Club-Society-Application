package com.example.xingyi.cs_helper;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Sunway_Student_Ambassadors extends Fragment {

    View view;
    SessionManagement session;

    private String htmlString =
            "<p><font color = 'black'><big><b>About Us</b></big></font><br>Sunway Student Ambassadors (SSA) is a student-run representative body that promotes the ideals of academic excellence and leadership in Sunway.\n" +
                    "categories</p><br>\n"+
                    "<p><font color = 'black'><big><b>Club Overview</b></big></font><br>Fostering bonds and connecting scholars of all different backgrounds and knowledge.</p><br>\n"+
                    "<p><font color = 'black'><big><b>Mission</b></big></font><br>- Enriching the quality and experience of scholars’ life at Sunway<br>\n" +
                    "- Cultivating a mind set in scholars to give back to society (in line with JCF founding principles)<br>\n" +
                    "- Creating an environment for scholars to develop leadership, persona/professional growth and heart of service<br>\n" +
                    "- Fostering bonds and connecting scholars of different backgrounds and knowledge<br>\n" +
                    "- Serving as idea generators for future events, initiatives and scholarship processes</p><br>\n"+
                    "<p><font color = 'black'><big><b>Contact Details</b></big></font><br>email: ssa@imail.sunway.edu.my<br>fb page: www.facebook.com/SunwayStudentAmbassadors</p>";

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.club_intropage, container, false);

        session = new SessionManagement(getActivity());

        TextView textView = (TextView)view.findViewById(R.id.club_textView);
        textView.setText(Html.fromHtml(htmlString));

        ImageView image = (ImageView)view.findViewById(R.id.club_intro);
        image.setImageResource(R.drawable.ssa);

        Button button = (Button) view.findViewById(R.id.club_join);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(session.isLoggedIn()){
                    Intent intent = new Intent(getActivity(), Member_Register_SSA.class);
                    startActivity(intent);
                }
                else {
                    session.checkLogin();
                }
            }
        });

        DatabaseHelper databaseHelper;
        databaseHelper = new DatabaseHelper(getActivity());
        String email = "15034051@imail.sunway.edu.my";
        String club = "Sunway Student Ambassadors";

        if(!databaseHelper.isEmailRegistered(email, club)){
            databaseHelper.addClubUser(new ClubUser(null, "xingyi", email, "BCS", club, "accept", "admin"));
        }

        return view;
    }
}
