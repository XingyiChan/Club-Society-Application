package com.example.xingyi.cs_helper;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Sunway_Student_Volunteer extends Fragment {

    View view;
    SessionManagement session;

    private String htmlString =
            "<p><font color = 'black'><big><b>About Us</b></big></font><br>Initiated by a group of 22 Sunway students in December 2010 and grown with the motto that \"Everyone Can Make A Difference\" as a Volunteer.</p><br>\n"+
                    "<p><font color = 'black'><big><b>Vision</b></big></font><br>To be a pioneer and benchmark in volunteering works bringing continuous positive impact and benefits to community and volunteers.</p><br>\n"+
                    "<p><font color = 'black'><big><b>Mission</b></big></font><br>- To reach out to people who needs help.<br>\n" +
                    "- To develop spirit of Volunteerism amongst Sunway University students.</p><br>\n"+
                    "<p><font color = 'black'><big><b>Motto</b></big></font><br>- Reaching hearts, touching lives<br>\n" +
                    "- Everyone can make a difference</p><br>\n"+
                    "<p><font color = 'black'><big><b>Contact Details</b></big></font><br>website: http://sunwaystudentvolunteers.wordpress.com<br>fb page: www.facebook.com/Sunwaystudentvolunteers</p>";

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.club_intropage, container, false);

        session = new SessionManagement(getActivity());

        TextView textView = (TextView) view.findViewById(R.id.club_textView);
        textView.setText(Html.fromHtml(htmlString));

        ImageView image = (ImageView) view.findViewById(R.id.club_intro);
        image.setImageResource(R.drawable.ssv);

        Button button = (Button) view.findViewById(R.id.club_join);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (session.isLoggedIn()) {
                    Intent intent = new Intent(getActivity(), Member_Register_SSV.class);
                    startActivity(intent);
                } else {
                    session.checkLogin();
                }
            }
        });

        DatabaseHelper databaseHelper;
        databaseHelper = new DatabaseHelper(getActivity());
        String email = "15034051@imail.sunway.edu.my";
        String club = "Sunway Student Volunteers";

        if(!databaseHelper.isEmailRegistered(email, club)){
            databaseHelper.addClubUser(new ClubUser(null, "xingyi", email, "BCS", club, "accept", "admin"));
        }

        return view;
    }
}
