package com.example.xingyi.cs_helper;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Sunway_University_Cheerleading extends Fragment {

    View view;
    SessionManagement session;

    private String htmlString =
            "<p><font color = 'black'><big><b>About Us</b></big></font><br>S.U.C - Sunway University Cheerleading.</p><br>\n" +
                    "<p><font color = 'black'><big><b>Awards</b></big></font><br>CHARM Cheerleading Championships 2014 (CHAMPION - Level 3)<br>\n" +
                    "Asia Cheerleading Invitational Championships 2015 (CHAMPION - Level 4)<br>\n" +
                    "CHARM Cheerleading Championships 2015 (CHAMPION - Level 5 Coed Medium)<br>\n" +
                    "CHARM Cheerleading Championships 2016 (CHAMPION - Level 5 Coed Medium)<br>\n" +
                    "R.AGE CHEER 2016 (CHAMPION - UNI COED)<br>\n" +
                    "Asia Cheerleading Invitational Championships 2017 (2nd Runner-up - Level 4)<br>\n" +
                    "CHARM Cheerleading Championships 2017 (CHAMPION - Level 5 Coed Medium)<br>\n" +
                    "CHARM Cheerleading Championships 2017 (1st Runner-up - COED OPEN)<br>\n" +
                    "R.AGE CHEER 2017 (1st Runner-up - UNI COED)<br>\n" +
                    "Asia Cheerleading Invitational Championships 2018 (1st Runner-up - Level 5)</p><br>\n"+
                    "<p><font color = 'black'><big><b>Contact Details</b></big></font><br>email: \n" +
                    "sunwaycheerleading@gmail.com<br>fb page: www.facebook.com/sunwaycheerleading</p>";

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.club_intropage, container, false);

        session = new SessionManagement(getActivity());

        TextView textView = (TextView)view.findViewById(R.id.club_textView);
        textView.setText(Html.fromHtml(htmlString));

        ImageView image = (ImageView)view.findViewById(R.id.club_intro);
        image.setImageResource(R.drawable.cheerleading);

        Button button = (Button) view.findViewById(R.id.club_join);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(session.isLoggedIn()){
                    Intent intent = new Intent(getActivity(), Member_Register_Cheerleading.class);
                    startActivity(intent);
                }
                else {
                    session.checkLogin();
                }
            }
        });

        DatabaseHelper databaseHelper;
        databaseHelper = new DatabaseHelper(getActivity());
        String email = "15034051@imail.sunway.edu.my";
        String club = "Sunway University Cheerleading";

        if(!databaseHelper.isEmailRegistered(email, club)){
            databaseHelper.addClubUser(new ClubUser(null, "xingyi", email, "BCS", club, "accept", "admin"));
        }

        return view;
    }
}
