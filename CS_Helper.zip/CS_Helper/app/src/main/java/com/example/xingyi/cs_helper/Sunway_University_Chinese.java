package com.example.xingyi.cs_helper;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Sunway_University_Chinese extends Fragment {

    View view;
    SessionManagement session;

    private String htmlString =
            "<p><font color = 'black'><big><b>About</b></big></font><br>Sunway University Chinese Cultural Society's official page.</p><br>\n" +
                    "<p><font color = 'black'><big><b>Mission</b></big></font><br>传承中华文化，奉献时代社稷。</p><br>\n" +
                    "<p><font color = 'black'><big><b>General Information</b></big></font><br>双威大学华文学会执委团 2018/19<br>SUCCS Executive Committee 2018/19<br><br>\n" +
                    "主席 President<br>叶奕锋 Yap Yi Feng<br><br>\n" +
                    "外务副主席 Vice-president (External Affairs<br>许顺智 Khor Shunzhi<br><br>\n" +
                    "内务副主席 Vice-president (Internal Affairs)<br>林艾迪 Lim Ai Di<br><br>\n" +
                    "秘书 Secretary<br>（正）赖政玮 Lai Zheng Wei<br>（副）王晴薇 Heng Cing Wooi<br><br>\n" +
                    "财政 Treasurer<br>林欣颖 Lam Xin Ying</p><br>\n"+
                    "<p><font color = 'black'><big><b>Contact Details</b></big></font><br>email: sunwaysuccs@gmail.com<br>fb page: www.facebook.com/sunwaysuccs</p>";

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.club_intropage, container, false);

        session = new SessionManagement(getActivity());

        TextView textView = (TextView)view.findViewById(R.id.club_textView);
        textView.setText(Html.fromHtml(htmlString));

        ImageView image = (ImageView)view.findViewById(R.id.club_intro);
        image.setImageResource(R.drawable.chinese);

        Button button = (Button) view.findViewById(R.id.club_join);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(session.isLoggedIn()){
                    Intent intent = new Intent(getActivity(), Member_Register_Chinese.class);
                    startActivity(intent);
                }
                else {
                    session.checkLogin();
                }
            }
        });

        DatabaseHelper databaseHelper;
        databaseHelper = new DatabaseHelper(getActivity());
        String email = "15034051@imail.sunway.edu.my";
        String club = "Sunway University Chinese Cultural Society";

        if(!databaseHelper.isEmailRegistered(email, club)){
            databaseHelper.addClubUser(new ClubUser(null, "xingyi", email, "BCS", club, "accept", "admin"));
        }

        return view;
    }
}
